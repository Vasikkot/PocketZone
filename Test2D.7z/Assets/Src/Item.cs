using System;
using UnityEngine;
using static UnityEditor.ShaderGraph.Internal.KeywordDependentCollection;

[Serializable]
public class Item : MonoBehaviour
{
    [SerializeField] private Sprite sprite;
    [SerializeField] private float dropChance = 0.1f;
    [SerializeField] private int id;

    public float DropChance
    {
        get => dropChance;
        set => dropChance = value;
    }

    public int Id
    {
        get => id;
        private set => id = value;
    }
    public Sprite Sprite { get => sprite; private set => sprite = value; }

    void Awake()
    {
        if (Sprite == null)
            Sprite = GetComponent<SpriteRenderer>().sprite;
    }

    public void SetNewItem(Item newItem)
    {
        GetComponent<SpriteRenderer>().sprite = newItem.Sprite;
        sprite = newItem.Sprite;
        Id = newItem.Id;
        DropChance = newItem.DropChance;
    }
    public Item Clone()
    {
        return (Item)this.MemberwiseClone();
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Player")) // ��������� ��� ������
        {
            InventoryData.instance?.AddItem(this);
            Destroy(gameObject);
        }
    }


}