using System;
using System.Collections.Generic;
using UnityEngine;

public class InventoryData : MonoBehaviour
{
    [SerializeField] private int maxSlots = 20;
     List<InventorySlotData> slots;
    public event Action SlotChanged;
    public static InventoryData instance;

    public List<InventorySlotData> Slots { get => slots; private set => slots = value; }
    private void Awake()
    {
        if (instance == null)
            instance = this;
        else
            Destroy(gameObject);
    }
    void Start()
    {
        Slots = new List<InventorySlotData>(maxSlots);
        FillInv();
    }


    public void AddItem(Item newItem, int count = 1)
    {

        InventorySlotData existingSlot = Slots.Find(slot => slot.ItemInInventory != null && slot.ItemInInventory.Id == newItem.Id);

        if (existingSlot != null)
        {

            Slots[existingSlot.Index].CountOfItems += count;
        }
        else
        {

            InventorySlotData emptySlot = Slots.Find(slot => slot.ItemInInventory == null);

            if (emptySlot != null)
            {

                Slots[emptySlot.Index].ItemInInventory = newItem.Clone();
                Slots[emptySlot.Index].CountOfItems = count;
            }
            else
            {
                Debug.Log("��������� �����! ���������� �������� ����� �������.");
            }
        }
        UpdateIndexes();
        SlotChanged?.Invoke();
    }
    public bool RemoveItem(int id, int count = 1)
    {
        InventorySlotData slotWithItem = Slots.Find(slot => slot.ItemInInventory != null && slot.ItemInInventory.Id == id);

        if (slotWithItem != null)
        {
            
            if (slotWithItem.CountOfItems > count)
            {
                slotWithItem.CountOfItems -= count;
            }
            else
            {

                Slots[slotWithItem.Index].ItemInInventory = null;
                Slots[slotWithItem.Index].CountOfItems = 0;
            }

           
            UpdateIndexes();
            SlotChanged?.Invoke();
            return true;
        }
        else
        {
            return false;


        }
    }

    public void FillInv()
    {
        Slots.Clear();
        for (int i = 0; i < maxSlots; i++)
        {
            Slots.Add(new InventorySlotData(null, 0, i));
        }
    }


    public void UpdateIndexes()
    {
        for (int i = 0; i < Slots.Count; i++)
        {
            Slots[i].Index = i;
        }
    }
}