using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InventorySlotData 
{
    Item itemInInventory;
    int countOfItems;
    int index;

    public int CountOfItems { get => countOfItems; set => countOfItems = value; }
    public Item ItemInInventory { get => itemInInventory; set => itemInInventory = value; }
    public int Index { get => index; set => index = value; }
    public InventorySlotData(Item item, int count, int index)
    {
        ItemInInventory = item;
        CountOfItems = count;
        Index = index;
    }
}
